<?php

return array(
	'title'         => __('Centered logo header', 'blockpress'),
	'categories'    => array('blockpress-header'),
	'blockTypes'    => array('core/template-part/header'),
 
	'content'       => '
	<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"25px","bottom":"25px"}},"color":{"background":"var(--wp--custom--color--white)","text":"var(--wp--custom--color--black)"}},"layout":{"inherit":true},"frStickyHeader":false} -->
<div class="wp-block-group alignfull has-background has-text-color"
    style="padding-top:25px;padding-bottom:25px;background-color:var(--wp--custom--color--white);color:var(--wp--custom--color--black);">
    <!-- wp:columns {"verticalAlignment":"center","isStackedOnMobile":false,"align":"wide"} -->
    <div class="wp-block-columns alignwide are-vertically-aligned-center is-not-stacked-on-mobile">
        <!-- wp:column {"verticalAlignment":"center"} -->
        <div class="wp-block-column is-vertically-aligned-center">
            <!-- wp:navigation {"layout":{"type":"flex","orientation":"horizontal"}} /-->
        </div>
        <!-- /wp:column -->

        <!-- wp:column {"verticalAlignment":"center"} -->
        <div class="wp-block-column is-vertically-aligned-center">
            <!-- wp:site-title {"level":0,"textAlign":"center"} /-->
        </div>
        <!-- /wp:column -->

        <!-- wp:column {"verticalAlignment":"center"} -->
        <div class="wp-block-column is-vertically-aligned-center">
            <!-- wp:social-links {"iconColor":"white","iconColorValue":"#fff","iconBackgroundColor":"black","iconBackgroundColorValue":"#000","className":"is-style-default","layout":{"type":"flex","justifyContent":"right"}} -->
            <ul class="wp-block-social-links has-icon-color has-icon-background-color is-style-default">
                <!-- wp:social-link {"url":"#","service":"facebook"} /-->

                <!-- wp:social-link {"url":"#","service":"instagram"} /-->

                <!-- wp:social-link {"url":"#","service":"twitter"} /-->
            </ul>
            <!-- /wp:social-links -->
        </div>
        <!-- /wp:column -->
    </div>
    <!-- /wp:columns -->
</div>
<!-- /wp:group -->',
);
