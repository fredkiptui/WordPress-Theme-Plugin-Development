<?php
// There is nothing output here because block themes do not use php templates.