import {Fragment} from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import PluginData from './PluginData';

const RecommendedContent = () => {
    return (
        <Fragment>
            <PluginData/>
        </Fragment>
    );
};

export default RecommendedContent;