<?php
 /**
  * Title: Home
  * Slug: gutenify-hustle/home
  * Categories: gutenify-hustle
  */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"blockGap":"0"}},"className":"has-no-underline","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-no-underline">
<!-- wp:pattern {"slug":"gutenify-hustle/home-banner"} /-->
<!-- wp:pattern {"slug":"gutenify-hustle/service"} /-->
<!-- wp:pattern {"slug":"gutenify-hustle/hero-section"} /-->
<!-- wp:pattern {"slug":"gutenify-hustle/call-to-action"} /-->
<!-- wp:pattern {"slug":"gutenify-hustle/video-content"} /-->
<!-- wp:pattern {"slug":"gutenify-hustle/latest-news"} /-->
</div>
<!-- /wp:group -->

