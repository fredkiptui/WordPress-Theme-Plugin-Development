<?php
 /**
  * Title: Service Page
  * Slug: gutenify-hustle/service-page
  * Categories: gutenify-hustle
  */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"blockGap":"0"}},"className":"has-no-underline","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-no-underline">
    <!-- wp:pattern {"slug":"gutenify-hustle/cover-with-post-title"} /-->
    <!-- wp:pattern {"slug":"gutenify-hustle/service"} /-->
</div>
<!-- /wp:group -->

